function f(input) {
    let a=100
    if(input){
        let b=a+1;
        return b;
    }

    return b;
}

f(true)