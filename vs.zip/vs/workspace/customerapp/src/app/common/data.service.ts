import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Customer } from './customer';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  baseCustomerUrl = 'http://localhost:3000/customers/';

  constructor(private http: HttpClient) { } // dependency injustion

  getCustomers(): Observable<Customer[]> {
    return this.http.get<Customer[]>(this.baseCustomerUrl);
  }

  getCustomer(id: number): Observable<Customer> {
    return this.http.get<Customer>(`${this.baseCustomerUrl}${id}`);
  }

  addCustomer(customer: Customer): Observable<any> {
    return this.http.post<any>(this.baseCustomerUrl, customer);
  }

  updateCustomer(customer: Customer): Observable<any> {
    return this.http.put<any>(`${this.baseCustomerUrl}${customer.id}`, customer);
  }

  deleteCustomer(id: number): Observable<any> {
    return this.http.delete<any>(`${this.baseCustomerUrl}${id}`);
  }

  getOrders(): Observable<any> {
    return this.http.get<any>('http://localhost:3000/orders');
  }

}
