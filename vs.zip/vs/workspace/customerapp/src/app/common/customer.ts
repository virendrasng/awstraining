export class Customer {
    id:number;
    firstName: string;
    lastName: string;
    gender: string;
    address: string;
    orders?: any;
}
