import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http' // used in services discussion
import { AppComponent } from './app.component';
import { CustomersComponent } from './customers/customers.component';
import { CustomerCardComponent } from './customers/customer-card/customer-card.component';
import { CustomerListComponent } from './customer-list/customer-list.component';
import { HoverDirective } from './hover.directive';
import { DataService } from './common/data.service';
import { HomeComponent } from './home/home.component';
import { FirstComponent } from './first/first.component';
import { SecondComponent } from './second/second.component';
import { CapsPipe } from './caps.pipe';
import { Routes, RouterModule } from '@angular/router';
import { CustomerEditComponent } from './customer-edit/customer-edit.component';
import { LinkActivate } from './common/link.activate';

const routes: Routes = [
  {
    path: '',
    component: HomeComponent
  },
  {
    path: 'customers',
    component: CustomersComponent
  },
  {
    path: 'orders',
    component: CustomersComponent
  },
  {
    path: 'customers/edit/:id',
    component: CustomerEditComponent
  }
];

@NgModule({
  declarations: [
    AppComponent,
    CustomersComponent,
    CustomerCardComponent,
    CustomerListComponent,
    HoverDirective,
    HomeComponent,
    FirstComponent,
    SecondComponent,
    CapsPipe,
    CustomerEditComponent
  ],
  imports: [
    BrowserModule, FormsModule, HttpClientModule, RouterMoudule.foorRoot(routes) // HttpClientModule is for services
  ],
  providers: [DataService, LinkActivate], // DataService added for service discussion
  bootstrap: [AppComponent]
})

export class AppModule { }
