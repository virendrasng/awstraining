function doTask() {
    return new Promise(function (res, rej) {
        setTimeout(() => {
            res("Success...");
        }, 1000);
    });
}

doTask().then(data => console.log(data), err => console.log("Error: " + err));

/*
doTask().then(function(data) {
    console.log(data); }
, function(err) {console.log(err);}
);
*/