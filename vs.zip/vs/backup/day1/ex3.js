var fs = require('fs');

var content = "";

// Non-Blocking API
var stream = fs.createReadStream("first.js");

stream.on("data", function(chunk){
    console.log(chunk.toString());
});

stream.on("end", function(){
    console.log("Done!");
});

stream.on("err", function(e){
    console.log("Err!"), e;
});

console.log("Outside: " + content.toString());
