var fs = require('fs');

var content = "";
fs.readFileSync("first.js", function (err, data){
    content = data;
    if(!err){
        console.log("Inside: " + content.toString());
    }
});

console.log("Outside: " + content.toString());
