npm init
mocha --reporter spec
npm i --save-dev mocha chai request (remove -dev for Prod environment)
PS D:\vs\day1\myapp> npm i -g mocha
In package.json file in ' "test": "mocha --reporter spec" ' dot can also be written in place of 'spec'. In the output then 2 dots will be displayed and not tick marks.