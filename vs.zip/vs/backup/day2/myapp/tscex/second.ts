export default function add(x:number, y:number) : number{
    return x + y;
}